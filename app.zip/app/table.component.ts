import {Component, Input} from '@angular/core';

@Component({
  selector: 'table-component',
  templateUrl: 'table.component.html',
  styleUrls: ['table.component.css']
})
export class TableComponent {
  @Input() data: { type: string, number: string, expiration: string, owner: string }[] = [{
            "type": "",
            "number": "",
            "expiration": "",
            "owner": ""
        }]
  rowDelete(i: number): void {
    this.data.splice(i, 1)
  }
}
