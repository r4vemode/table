import {Component, Input} from '@angular/core';

@Component({
  selector: 'some-component',
  templateUrl: 'some.component.html',
  styleUrls: []
})
export class SomeComponent {
  title: string = 'this is the end'
  someText: string = 'thanks for using angular'
  @Input() someData: string = '';
}
