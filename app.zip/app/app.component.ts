import { Component } from '@angular/core';

@Component({
  selector: 'main-app',
  templateUrl: './app.component.html',
  styleUrls: []
})
export class AppComponent {
  title: string = 'Credit Cards';
  someData: string = 'Thanks for checking'
  creditCardsData: { type: string, number: string, expiration: string, owner: string }[] = [
        {
            "type": "MasterCard",
            "number": "4024007107180100",
            "expiration": "06/22",
            "owner": "Green Krajcik"
        },
        {
            "type": "Visa",
            "number": "5170372228979007",
            "expiration": "06/22",
            "owner": "Verner Schmeler"
        },
        {
            "type": "Visa Retired",
            "number": "347089775821759",
            "expiration": "11/22",
            "owner": "Rosetta Jaskolski"
        },
        {
            "type": "MasterCard",
            "number": "4916170653243952",
            "expiration": "08/23",
            "owner": "Yadira Swift"
        },
        {
            "type": "MasterCard",
            "number": "6011982938089797",
            "expiration": "07/23",
            "owner": "Delfina Kertzmann"
        },
        {
            "type": "Visa",
            "number": "374234508355370",
            "expiration": "02/24",
            "owner": "Reginald Goldner"
        },
        {
            "type": "Visa",
            "number": "5130286047870115",
            "expiration": "06/22",
            "owner": "Clair Block"
        },
        {
            "type": "Visa",
            "number": "4024007189604",
            "expiration": "10/24",
            "owner": "Calista Shields"
        },
        {
            "type": "Visa",
            "number": "4539508974718284",
            "expiration": "08/24",
            "owner": "Manuela Hermiston"
        },
        {
            "type": "Visa",
            "number": "4539350188811914",
            "expiration": "03/22",
            "owner": "Augustus Herzog"
        },
        {
            "type": "American Express",
            "number": "4485626684020",
            "expiration": "02/24",
            "owner": "Devon Kertzmann"
        },
        {
            "type": "MasterCard",
            "number": "2373410368818478",
            "expiration": "01/24",
            "owner": "Brock Hoppe"
        },
        {
            "type": "MasterCard",
            "number": "2643253861570061",
            "expiration": "03/22",
            "owner": "Alphonso Kessler"
        },
        {
            "type": "American Express",
            "number": "2532041906723900",
            "expiration": "01/25",
            "owner": "Petra Braun"
        },
        {
            "type": "Visa",
            "number": "2554985954173595",
            "expiration": "04/24",
            "owner": "Jalyn Hodkiewicz"
        },
        {
            "type": "MasterCard",
            "number": "5263386121357481",
            "expiration": "10/24",
            "owner": "Clinton Romaguera"
        },
        {
            "type": "Visa",
            "number": "2221229333231359",
            "expiration": "01/23",
            "owner": "Kris O'Kon"
        },
        {
            "type": "MasterCard",
            "number": "2639974631774198",
            "expiration": "03/22",
            "owner": "Shyann Kuhlman"
        },
        {
            "type": "American Express",
            "number": "4716872782357015",
            "expiration": "09/23",
            "owner": "Estrella Reilly"
        },
        {
            "type": "Discover Card",
            "number": "5191392317145190",
            "expiration": "11/22",
            "owner": "Raphaelle Durgan"
        },
        {
            "type": "American Express",
            "number": "379104811034621",
            "expiration": "10/24",
            "owner": "Melissa Turcotte"
        },
        {
            "type": "Discover Card",
            "number": "4539763761981567",
            "expiration": "12/22",
            "owner": "Rory D'Amore"
        },
        {
            "type": "MasterCard",
            "number": "4868356952970381",
            "expiration": "07/23",
            "owner": "Stan Hermiston"
        },
        {
            "type": "American Express",
            "number": "4916220623044848",
            "expiration": "03/23",
            "owner": "Woodrow Altenwerth"
        },
        {
            "type": "MasterCard",
            "number": "5277560495970921",
            "expiration": "01/25",
            "owner": "Kevin Fadel"
        },
        {
            "type": "MasterCard",
            "number": "5281110998543181",
            "expiration": "08/24",
            "owner": "Joy Goldner"
        },
        {
            "type": "Visa",
            "number": "5299101773544247",
            "expiration": "03/22",
            "owner": "Rosemarie Abernathy"
        },
        {
            "type": "MasterCard",
            "number": "4485710314671819",
            "expiration": "12/24",
            "owner": "Britney Cole"
        },
        {
            "type": "Visa",
            "number": "5184893209134118",
            "expiration": "11/23",
            "owner": "Natalie Hintz"
        },
        {
            "type": "MasterCard",
            "number": "2221446553164165",
            "expiration": "10/22",
            "owner": "Earline Brekke"
        },
        {
            "type": "MasterCard",
            "number": "4556830652735374",
            "expiration": "11/24",
            "owner": "Amiya Jast"
        },
        {
            "type": "Visa Retired",
            "number": "5496649519947554",
            "expiration": "02/23",
            "owner": "Luz Collins"
        },
        {
            "type": "Visa",
            "number": "4929538136663712",
            "expiration": "12/22",
            "owner": "Aliyah Dare"
        },
        {
            "type": "Discover Card",
            "number": "4024007127552841",
            "expiration": "10/23",
            "owner": "Bennett Jacobs"
        },
        {
            "type": "MasterCard",
            "number": "4539359569558",
            "expiration": "10/24",
            "owner": "Rosario Kozey"
        },
        {
            "type": "MasterCard",
            "number": "6011763038234628",
            "expiration": "11/24",
            "owner": "Tatyana Skiles"
        },
        {
            "type": "MasterCard",
            "number": "4532848716898",
            "expiration": "09/23",
            "owner": "Chaz Batz"
        },
        {
            "type": "MasterCard",
            "number": "5165193217447450",
            "expiration": "04/24",
            "owner": "Stephanie Nienow"
        },
        {
            "type": "Visa Retired",
            "number": "6011161894963499",
            "expiration": "10/22",
            "owner": "Ferne Considine"
        },
        {
            "type": "MasterCard",
            "number": "5472923164100480",
            "expiration": "10/23",
            "owner": "Joseph Shanahan"
        },
        {
            "type": "Visa",
            "number": "6011078909991465",
            "expiration": "04/23",
            "owner": "Una Pacocha"
        },
        {
            "type": "MasterCard",
            "number": "6011853167476916",
            "expiration": "05/23",
            "owner": "Isaiah Schroeder"
        },
        {
            "type": "MasterCard",
            "number": "2323410333284021",
            "expiration": "06/24",
            "owner": "Denis Ratke"
        },
        {
            "type": "Visa Retired",
            "number": "5508118784950244",
            "expiration": "07/22",
            "owner": "America Kreiger"
        },
        {
            "type": "MasterCard",
            "number": "4532914710951030",
            "expiration": "08/23",
            "owner": "Dixie Collins"
        },
        {
            "type": "Visa",
            "number": "371927477571231",
            "expiration": "07/23",
            "owner": "Brionna Lindgren"
        },
        {
            "type": "MasterCard",
            "number": "4556974159083860",
            "expiration": "03/24",
            "owner": "Lindsey Robel"
        },
        {
            "type": "Visa",
            "number": "2720931366256239",
            "expiration": "04/22",
            "owner": "Mavis Baumbach"
        },
        {
            "type": "MasterCard",
            "number": "4485343793725292",
            "expiration": "08/22",
            "owner": "Verlie Crist"
        },
        {
            "type": "Discover Card",
            "number": "4916160001767",
            "expiration": "08/24",
            "owner": "Destinee Dooley"
        }
    ]
}
